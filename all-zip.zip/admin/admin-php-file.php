<?php

echo "Insert shortcode anywhere on your page: [donate]My Text Here[/donate]"